# LabQuest deployment guide

This project uses a React/Vite frontend served by an Express backend. Deploy the whole application as a Node/Docker web service (rather than a static-only site) so the `/api` routes remain available.

## Suggested path: Render Web Service

1. Push the updated project files to your GitHub repository.
2. In Render, create a **New Web Service** and connect `moodyshegs/LabQuest`.
3. Choose the Docker runtime so Render uses the repository's `Dockerfile`.
4. Set the health-check path to `/api/health` if the Render plan/settings expose that option.
5. Add a managed MySQL-compatible database and set `DATABASE_URL` in the web service's environment variables. Do not commit this value to GitHub.
6. Deploy and wait for the service to become healthy.
7. Open the generated `https://...onrender.com` URL and test the landing page, dashboards, and `/api/health`.

The exact public website URL is created by the hosting provider after deployment; it cannot be truthfully stated before that step.

## Before real school use

- The Student / Teacher / Admin switcher is a **demo role preview**, not a login system.
- Implement verified authentication, server-side role checks, school tenancy/isolation, and audit logs before using real student information.
- The practical video player accepts an optional `videoUrl` and `videoPoster` field on each practical. Upload or generate reviewed videos, store them in a secure media service, and add the approved URLs to the practical records.
- AI video generation is not connected in this prototype. Add a server-side integration with a video-generation provider if you want the videos generated automatically. Keep all provider API keys on the server, never in frontend code.
- Do not use a public static hosting target alone for this project; the Express API and database configuration must be deployed too.
